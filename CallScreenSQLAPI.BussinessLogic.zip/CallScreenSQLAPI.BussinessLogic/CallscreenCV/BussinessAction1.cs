﻿using System;
using System.Collections.Generic;
using System.Text;
using CallScreenSQLAPI.DataAccess.CallscreenCV;
using CallScreenCenterModel.CallscreenCV;
namespace CallScreenSQLAPI.BussinessLogic.CallscreenCV
{
    public partial class BussinessAction
    {
        public void GetDataDataBases(out DataBasesModel[] dataObjects)
        {
            Repository Rep = null;
            bool internalConnection = false;
            internalConnection = ChkInConnectionSQL(ref Rep);
            dataObjects = null;
            try
            {
                Rep.GetDataDataBases(out dataObjects);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (internalConnection)
                {
                    Rep.CloseConnection();
                    Rep = null;
                }
            }
        }

        public void GetAUTHORITYPE(out AUTHORITYPE[] dataObjects)
        {
            Repository Rep = null;
            bool internalConnection = false;
            internalConnection = ChkInConnectionSQL(ref Rep);
            dataObjects = null;
            try
            {
                Rep.GetAUTHORITYPE(out dataObjects);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (internalConnection)
                {
                    Rep.CloseConnection();
                    Rep = null;
                }
            }
        }
    }
}
