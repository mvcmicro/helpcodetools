﻿using System;
using System.Collections.Generic;
using System.Text;
using CallScreenSQLAPI.DataAccess.CallscreenCV;
using CallScreenCenterModel._CenterModule;
namespace CallScreenSQLAPI.BussinessLogic.CallscreenCV
{
    public partial class BussinessAction
    {
        private AppSettingModel AppSeting;
        public BussinessAction(AppSettingModel appSeting)
        {
            this.AppSeting = appSeting;
        }
        public bool ChkInConnectionSQL(ref Repository Rep, bool IsTrn = false)
        {
            bool internalConnection = false;
            try
            {
                if (Rep == null)
                {
                    Rep = new Repository(AppSeting.ConnectionStringSQL);
                    Rep.OpenConnection();
                    if (IsTrn == true)
                    {
                        Rep.beginTransaction();
                    }
                }
                internalConnection = true;
            }
            catch (Exception ex)
            {
                internalConnection = false;
                throw ex;
            }
            return internalConnection;
        }
    }
}
