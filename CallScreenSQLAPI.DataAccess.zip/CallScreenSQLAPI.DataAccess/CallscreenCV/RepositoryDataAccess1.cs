﻿using System;
using System.Collections.Generic;
using System.Text;
using CallScreenCenterModel.CallscreenCV;
using DataAccessUtility.SqlServer;
namespace CallScreenSQLAPI.DataAccess.CallscreenCV
{
    public partial class Repository
    {
        public void GetDataDataBases(out DataBasesModel[] dataObjects)
        {
            StringBuilder str = new StringBuilder();
            str.Append("SELECT DB_NAME(DATABASE_ID) AS [DATABASE], DATABASE_ID  FROM SYS.DATABASES ");
            dataObjects = RepositorySqlServerUtility.FillDataTable<DataBasesModel>(str.ToString(), connection);
        }

        public void GetAUTHORITYPE(out AUTHORITYPE[] dataObjects)
        {
            StringBuilder str = new StringBuilder();
            str.Append("SELECT *  FROM dbo.AUTHORITYPE ");
            dataObjects = RepositorySqlServerUtility.FillDataTable<AUTHORITYPE>(str.ToString(), connection);
        }
    }

}
