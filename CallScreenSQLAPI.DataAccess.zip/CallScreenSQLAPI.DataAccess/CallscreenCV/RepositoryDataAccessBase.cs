﻿using System;
using System.Collections.Generic;
using System.Text;
using DataAccessUtility.SqlServer;
namespace CallScreenSQLAPI.DataAccess.CallscreenCV
{
    public partial class Repository : RepositorySqlServerBase
    {
        public Repository() : base()
        {
        }
        public Repository(string ConnectionName) : base(ConnectionName)
        {

        }

    }
}
