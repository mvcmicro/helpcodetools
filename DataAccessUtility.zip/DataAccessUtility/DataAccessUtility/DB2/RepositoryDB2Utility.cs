﻿using System;
using System.Collections.Generic;
using System.Data;
using IBM.Data.DB2.Core;
using System.Linq;
using System.Text;
using System.Reflection;
using System.Diagnostics;
using System.Threading;
namespace DataAccessUtility.DB2
{
    public class DBParameter
    {
        public string NAME { get; set; }
        public object VALUE { get; set; }
        public SqlDbType DbTYPE { get; set; }
        public int SIZE { get; set; }
        public DBParameter()
        {
        }

        public DBParameter(string IN_NAME, object IN_VALUE, SqlDbType IN_TYPE, int IN_SIZE)
        {
            this.NAME = IN_NAME;
            if (IN_VALUE == null)
            {
                this.VALUE = DBNull.Value;
            }
            else if (IN_VALUE is DBNull)
            {
                this.VALUE = DBNull.Value;

            }
            else
            {
                this.VALUE = IN_VALUE;
            }
            this.DbTYPE = IN_TYPE;
            this.SIZE = IN_SIZE;
        }

        public void testthraed()
        {

            ManualResetEvent resetEvent = null;
            List<ManualResetEvent> events = new List<ManualResetEvent>();
            resetEvent = new ManualResetEvent(false);

            DateTime? STARTDATE = null; ;
            DateTime? ENDDATE = null; ;
            string CultureName = null; ;


            ThreadPool.QueueUserWorkItem(function1, new object[] { STARTDATE, ENDDATE, CultureName, resetEvent });
            events.Add(resetEvent);

            ThreadPool.QueueUserWorkItem(function2, new object[] { STARTDATE, ENDDATE, CultureName, resetEvent });
            events.Add(resetEvent);

            ThreadPool.QueueUserWorkItem(function2, new object[] { STARTDATE, ENDDATE, CultureName, resetEvent });
            events.Add(resetEvent);

            WaitHandle.WaitAll(events.ToArray());

        }

        //object data1 = null;
        public void function1(object objectStatInfo)
        {
            object[] objArray = objectStatInfo as object[];

            DateTime? STARTDATE = (DateTime?)objArray[0];
            DateTime? ENDDATE = (DateTime?)objArray[1];
            string CultureName = (string)objArray[2];
            //  เขียน function ตรงนี้ outออกมา ใส่ใน data1
            ManualResetEvent resetEvent = objArray[3] as ManualResetEvent;
            resetEvent.Set();
        }

        public void function2(object objectStatInfo)
        {
            object[] objArray = objectStatInfo as object[];

            DateTime? STARTDATE = (DateTime?)objArray[0];
            DateTime? ENDDATE = (DateTime?)objArray[1];
            string CultureName = (string)objArray[2];
            //  เขียน function ตรงนี้ outออกมา ใส่ใน data1
            ManualResetEvent resetEvent = objArray[3] as ManualResetEvent;
            resetEvent.Set();
        }
        public void function3(object objectStatInfo)
        {
            object[] objArray = objectStatInfo as object[];

            DateTime? STARTDATE = (DateTime?)objArray[0];
            DateTime? ENDDATE = (DateTime?)objArray[1];
            string CultureName = (string)objArray[2];
            //  เขียน function ตรงนี้ outออกมา ใส่ใน data1
            ManualResetEvent resetEvent = objArray[3] as ManualResetEvent;
            resetEvent.Set();
        }
    }
    public static class RepositoryDB2Utility
    {
        public static DataTable FillDataTable(DB2Command oCmd, DB2Connection connection)
        {
            oCmd.Connection = connection;
            using (DB2DataReader oReader = oCmd.ExecuteReader())
            {
                using (DataTable dataTable = new DataTable())
                {
                    dataTable.Load(oReader);
                    oReader.Close();
                    return dataTable;
                }
            }
        }
        public static DataTable FillDataTable(string sqlStr, DB2Connection connection)
        {
            DB2DataAdapter oAdpt = new DB2DataAdapter(sqlStr, connection);
            DataTable dt = new DataTable();
            oAdpt.Fill(dt);
            oAdpt.Dispose();
            return dt;
        }
        public static DataTable FillDataTable(string sqlStr, DB2Connection connection, List<DBParameter> param = null)
        {
            DB2Command cmd = new DB2Command(sqlStr, connection);
            DataTable dt = new DataTable();
            cmd.Parameters.Clear();
            if (param != null && param.Any())
            {
                foreach (DBParameter item in param)
                {
                    cmd.Parameters.Add(new DB2Parameter(item.NAME, item.DbTYPE)).Value = item.VALUE;
                }
            }
            using (DB2DataReader reader = cmd.ExecuteReader())
            {
                dt.Load(reader);
                reader.Close();
            }
            cmd.Dispose();
            return dt;
        }
        public static T[] FillDataTable<T>(string sqlStr, DB2Connection connection) where T : new()
        {
            DB2DataAdapter oAdpt = new DB2DataAdapter(sqlStr, connection);
            DataTable dt = new DataTable();
            IEnumerable<T> result;
            oAdpt.Fill(dt);
            oAdpt.Dispose();
            result = dt.AsEnumerable<T>();
            dt.Dispose();
            return result.ToArray();
        }
        public static T[] FillDataTable<T>(string sqlStr, DB2Connection connection, List<DBParameter> param) where T : new()
        {
            DB2Command cmd = new DB2Command(sqlStr, connection);
            DataTable dt = new DataTable();
            IEnumerable<T> result;
            if (param != null && param.Any())
            {
                cmd.Parameters.Clear();

                foreach (DBParameter item in param)
                {
                    cmd.Parameters.Add(new DB2Parameter(item.NAME, item.DbTYPE)).Value = item.VALUE;

                }
            }
            using (DB2DataReader reader = cmd.ExecuteReader())
            {
                dt.Load(reader);
            }
            cmd.Dispose();
            result = dt.AsEnumerable<T>();
            dt.Dispose();
            return result.ToArray();
        }
        public static object ExecuteScalar(DB2Connection conn, string sqlStr)
        {
            DB2Command oCmd = new DB2Command(sqlStr, conn);

            object returnValue = oCmd.ExecuteScalar();
            oCmd.Dispose();
            return returnValue;
        }
        public static object ExecuteScalar(DB2Connection conn, string sqlStr, List<DBParameter> DBParams)
        {
            DB2Command oCmd = new DB2Command(sqlStr, conn);

            if (DBParams != null && DBParams.Any())
            {
                oCmd.Parameters.Clear();
                foreach (DBParameter item in DBParams)
                {
                    oCmd.Parameters.Add(new DB2Parameter(item.NAME, item.DbTYPE)).Value = item.VALUE;
                }
            }
            object returnValue = oCmd.ExecuteScalar();
            oCmd.Dispose();
            return returnValue;
        }
        public static int ExecuteNonQuery(DB2Connection conn, string sqlStr)
        {
            DB2Command oCmd = new DB2Command(sqlStr, conn);
            int i = oCmd.ExecuteNonQuery();
            oCmd.Dispose();
            return i;
        }
        public static int ExecuteNonQuery(string sqlStr, DB2Connection conn, List<DBParameter> DBParams)
        {
            DB2Command oCmd = new DB2Command(sqlStr, conn);

            if (DBParams != null && DBParams.Any())
            {
                oCmd.Parameters.Clear();
                foreach (DBParameter item in DBParams)
                {
                    oCmd.Parameters.Add(new DB2Parameter(item.NAME, item.DbTYPE)).Value = item.VALUE;
                }
            }
            int i = oCmd.ExecuteNonQuery();
            oCmd.Dispose();
            return i;
        }
    }
}
