﻿using System;
using System.Collections.Generic;
using System.Text;
using IBM.Data.DB2.Core;
namespace DataAccessUtility.DB2
{
    public class RepositoryDB2Base
    {
        public RepositoryDB2Base()
        {

        }

        public RepositoryDB2Base(string ConnectionString)
        {
            try
            {
                CreateConstructor(ConnectionString);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private void CreateConstructor(string ConnectionString)
        {
            connection = new DB2Connection(ConnectionString);
        }

        protected DB2Connection connection;
        public DB2Connection Connection
        {
            get { return connection; }
            set { connection = value; }
        }

        public void OpenConnection()
        {
            connection.Open();
        }
        public void CloseConnection()
        {
            connection.Close();
            connection.Dispose();
        }
        protected DB2Transaction transaction;
        public void beginTransaction()
        {
            transaction = connection.BeginTransaction();
        }
        public void commitTransaction()
        {
            transaction.Commit();
            transaction.Dispose();
        }
        public void rollbackTransaction()
        {
            transaction.Rollback();
            transaction.Dispose();
        }
    }
}
