﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace DataAccessUtility.SqlServer
{
    public class RepositorySqlServerBase
    {
        public RepositorySqlServerBase()
        {

        }
        public RepositorySqlServerBase(string ConnectionString)
        {
            try
            {
                CreateConstructor(ConnectionString);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private void CreateConstructor(string ConnectionString)
        {
            connection = new SqlConnection(ConnectionString);
        }
        private string _ConnectionString;
        public string ConnectionString
        {
            get { return _ConnectionString; }
            set
            {
                _ConnectionString = value;
                connection = new SqlConnection(value);
            }
        }
        protected SqlConnection connection;
        public SqlConnection Connection
        {
            get { return connection; }
            set { connection = value; }
        }


        public void OpenConnection()
        {
            connection.Open();
        }
        public void CloseConnection()
        {
            connection.Close();
            connection.Dispose();
        }
        protected SqlTransaction transaction;
        public void beginTransaction()
        {
            transaction = connection.BeginTransaction();
        }
        public void commitTransaction()
        {
            transaction.Commit();
            transaction.Dispose();
        }
        public void rollbackTransaction()
        {
            transaction.Rollback();
            transaction.Dispose();
        }

        #region "[SysDate]"

        private DateTime _SysDate;

        public DateTime SysDate
        {
            get
            {
                if (_SysDate == default(DateTime))
                {
                    GetDbSysDate();
                    return _SysDate;
                }
                else
                {
                    return _SysDate;
                }
            }
            set { _SysDate = value; }
        }

        public void GetDbSysDate()
        {
            string sqlStr = "select getdate()"; SqlCommand oCmd = new SqlCommand(sqlStr, connection);
            SysDate = Convert.ToDateTime(oCmd.ExecuteScalar());
        }

        #endregion "[SysDate]"


      



    }
}
