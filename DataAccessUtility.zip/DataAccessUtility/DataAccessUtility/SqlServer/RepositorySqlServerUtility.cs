﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Reflection;
using System.Diagnostics;
using System.Threading;
namespace DataAccessUtility.SqlServer
{
    public class DBParameter
    {
        public string NAME { get; set; }
        public object VALUE { get; set; }
        public SqlDbType DbTYPE { get; set; }
        public int SIZE { get; set; }
        public DBParameter() {
        }

        public DBParameter(string IN_NAME, object IN_VALUE, SqlDbType IN_TYPE, int IN_SIZE)
        {
            this.NAME = IN_NAME;
            if (IN_VALUE == null)
            {
                this.VALUE = DBNull.Value;
            }
            else if (IN_VALUE is DBNull)
            {
                this.VALUE = DBNull.Value;

            }
            else
            {
                this.VALUE = IN_VALUE;
            }
            this.DbTYPE = IN_TYPE;
            this.SIZE = IN_SIZE;
        }

        public void testthraed()
        {

            ManualResetEvent resetEvent = null;
            List<ManualResetEvent> events = new List<ManualResetEvent>();
            resetEvent = new ManualResetEvent(false);

            DateTime? STARTDATE = null; ;
            DateTime? ENDDATE = null; ;
            string CultureName = null; ;


            ThreadPool.QueueUserWorkItem(function1, new object[] { STARTDATE, ENDDATE, CultureName, resetEvent });
            events.Add(resetEvent);

            ThreadPool.QueueUserWorkItem(function2, new object[] { STARTDATE, ENDDATE, CultureName, resetEvent });
            events.Add(resetEvent);

            ThreadPool.QueueUserWorkItem(function2, new object[] { STARTDATE, ENDDATE, CultureName, resetEvent });
            events.Add(resetEvent);

            WaitHandle.WaitAll(events.ToArray());

        }

        
        public void function1(object objectStatInfo)
        {
            object[] objArray = objectStatInfo as object[];

            DateTime? STARTDATE = (DateTime?)objArray[0];
            DateTime? ENDDATE = (DateTime?)objArray[1];
            string CultureName = (string)objArray[2];
            //  เขียน function ตรงนี้ outออกมา ใส่ใน data1
            ManualResetEvent resetEvent = objArray[3] as ManualResetEvent;
            resetEvent.Set();
        }

        public void function2(object objectStatInfo)
        {
            object[] objArray = objectStatInfo as object[];

            DateTime? STARTDATE = (DateTime?)objArray[0];
            DateTime? ENDDATE = (DateTime?)objArray[1];
            string CultureName = (string)objArray[2];
            //  เขียน function ตรงนี้ outออกมา ใส่ใน data1
            ManualResetEvent resetEvent = objArray[3] as ManualResetEvent;
            resetEvent.Set();
        }
        public void function3(object objectStatInfo)
        {
            object[] objArray = objectStatInfo as object[];

            DateTime? STARTDATE = (DateTime?)objArray[0];
            DateTime? ENDDATE = (DateTime?)objArray[1];
            string CultureName = (string)objArray[2];
            //  เขียน function ตรงนี้ outออกมา ใส่ใน data1
            ManualResetEvent resetEvent = objArray[3] as ManualResetEvent;
            resetEvent.Set();
        }
    }
    public static class RepositorySqlServerUtility
    {
        public static DataTable FillDataTable(SqlCommand oCmd, SqlConnection connection)
        {
            oCmd.Connection = connection;
            using (SqlDataReader oReader = oCmd.ExecuteReader())
            {
                using (DataTable dataTable = new DataTable())
                {
                    dataTable.Load(oReader);
                    oReader.Close();
                    return dataTable;
                }
            }
        }
        public static DataTable FillDataTable(string sqlStr, SqlConnection connection)
        {
            SqlDataAdapter oAdpt = new SqlDataAdapter(sqlStr, connection);
            DataTable dt = new DataTable();
            oAdpt.Fill(dt);
            oAdpt.Dispose();
            return dt;
        }
        public static DataTable FillDataTable(string sqlStr, SqlConnection connection, List<DBParameter> param = null)
        {
            SqlCommand cmd = new SqlCommand(sqlStr, connection);
            DataTable dt = new DataTable();
            cmd.Parameters.Clear();
            if (param != null && param.Any())
            {
                foreach (DBParameter item in param)
                {
                    cmd.Parameters.Add(new SqlParameter(item.NAME, item.DbTYPE)).Value = item.VALUE;
                }
            }
            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                dt.Load(reader);
                reader.Close();
            }
            cmd.Dispose();
            return dt;
        }
        public static T[] FillDataTable<T>(string sqlStr, SqlConnection connection) where T : new()
        {
            SqlDataAdapter oAdpt = new SqlDataAdapter(sqlStr, connection);
            DataTable dt = new DataTable();
            IEnumerable<T> result;
            oAdpt.Fill(dt);
            oAdpt.Dispose();
            result = dt.AsEnumerable<T>();
            dt.Dispose();
            return result.ToArray();
        }
        public static T[] FillDataTable<T>(string sqlStr, SqlConnection connection, List<DBParameter> param) where T : new()
        {
            SqlCommand cmd = new SqlCommand(sqlStr, connection);
            DataTable dt = new DataTable();
            IEnumerable<T> result;
            if (param != null && param.Any())
            {
                cmd.Parameters.Clear();

                foreach (DBParameter item in param)
                {
                    cmd.Parameters.Add(new SqlParameter(item.NAME, item.DbTYPE)).Value = item.VALUE;

                }
            }
            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                dt.Load(reader);
            }
            cmd.Dispose();
            result = dt.AsEnumerable<T>();
            dt.Dispose();
            return result.ToArray();
        }
        public static object ExecuteScalar(SqlConnection conn, string sqlStr)
        {
            SqlCommand oCmd = new SqlCommand(sqlStr, conn);

            object returnValue = oCmd.ExecuteScalar();
            oCmd.Dispose();
            return returnValue;
        }
        public static object ExecuteScalar(SqlConnection conn, string sqlStr, List<DBParameter> DBParams)
        {
            SqlCommand oCmd = new SqlCommand(sqlStr, conn);

            if (DBParams != null && DBParams.Any())
            {
                oCmd.Parameters.Clear();
                foreach (DBParameter item in DBParams)
                {
                    oCmd.Parameters.Add(new SqlParameter(item.NAME, item.DbTYPE)).Value = item.VALUE;
                }
            }
            object returnValue = oCmd.ExecuteScalar();
            oCmd.Dispose();
            return returnValue;
        }
        public static int ExecuteNonQuery(SqlConnection conn, string sqlStr)
        {
            SqlCommand oCmd = new SqlCommand(sqlStr, conn);
            int i = oCmd.ExecuteNonQuery();
            oCmd.Dispose();
            return i;
        }
        public static int ExecuteNonQuery(string sqlStr, SqlConnection conn, List<DBParameter> DBParams)
        {
            SqlCommand oCmd = new SqlCommand(sqlStr, conn);

            if (DBParams != null && DBParams.Any())
            {
                oCmd.Parameters.Clear();
                foreach (DBParameter item in DBParams)
                {
                    oCmd.Parameters.Add(new SqlParameter(item.NAME, item.DbTYPE)).Value = item.VALUE;
                }
            }
            int i = oCmd.ExecuteNonQuery();
            oCmd.Dispose();
            return i;
        }
    }
}
