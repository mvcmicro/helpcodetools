﻿using CallScreenCenterModel._CenterModule;
using CallScreenSQLAPI.BussinessLogic.CallscreenCV;
namespace CallScreenSQLAPI.ActionService.CallscreenCV
{
    public partial class CoreService : ICoreService
    {
        private AppSettingModel appsettingmodel;
        private BussinessAction logic = null;
        private ResponseHttpModel Res = null;
        public CoreService() { }
        public CoreService(AppSettingModel appset)
        {
            appsettingmodel = appset;
            logic = new BussinessAction(appsettingmodel);
            Res = new ResponseHttpModel();
        }
    }
}
