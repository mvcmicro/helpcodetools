﻿using CallScreenCenterModel.CallscreenCV;
using CallScreenCenterModel._CenterModule;
using System;
using System.Linq;
namespace CallScreenSQLAPI.ActionService.CallscreenCV
{
    public partial class CoreService : ICoreService
    {   
        public ResponseHttpModel GetDataDataBases()
        {
            DataBasesModel[] dataObjects = null;
            try
            {
                logic.GetDataDataBases(out dataObjects);
                Res.Data = dataObjects.ToList();
                Res.pr(null, true);
            }
            catch (Exception ex)
            {
                dataObjects = null;
                Res.ErrorDomain = "localhost:5003";
                Res.ErrorAppCode = "API:CallScreenSQLAPI";
                Res.ErrorFunctionName = "CoreService.GetDataDataBases";
                Res.Data = null;
                Res.pr(ex, false);
            }
            return Res;
        }
        public ResponseHttpModel GetAUTHORITYPE()
        {
            AUTHORITYPE[] dataObjects = null;
            try
            {
                logic.GetAUTHORITYPE(out dataObjects);
                Res.Data = dataObjects.ToList();
                Res.pr(null, true);
            }
            catch (Exception ex)
            {
                dataObjects = null;
                Res.ErrorDomain = "localhost:5003";
                Res.ErrorAppCode = "API:CallScreenSQLAPI";
                Res.ErrorFunctionName = "CoreService.GetAUTHORITYPE";
                Res.Data = null;
                Res.pr(ex, false);
            }
            return Res;
        }
    }
}
