﻿
namespace CallScreenSQLAPI.ActionService.CallscreenCV
{
    public partial interface ICoreService { }
}
