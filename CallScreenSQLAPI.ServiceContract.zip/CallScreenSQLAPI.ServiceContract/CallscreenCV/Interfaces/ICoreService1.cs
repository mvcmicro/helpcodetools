﻿
using CallScreenCenterModel._CenterModule;
namespace CallScreenSQLAPI.ActionService.CallscreenCV
{
    public  partial  interface ICoreService
    {
        ResponseHttpModel GetDataDataBases();

        ResponseHttpModel GetAUTHORITYPE();
    }
}
