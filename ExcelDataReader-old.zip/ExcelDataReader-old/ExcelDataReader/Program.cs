﻿
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Text;



namespace ExcelDataReader
{
    class Program
    {
        static void Main(string[] args)
        {
            string filePath = @"D:\@ProjectVB2015\ExcelDataReader\ExcelDataReader\สมุดงาน1.xlsx";
            Microsoft.Office.Interop.Excel.Application ExcelObj = null;
            ExcelObj = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel.Workbook theWorkbook = ExcelObj.Workbooks.Open(filePath, 0, true, 5, "", "", true, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "\t", false, false, 0, true);
            // get the collection of sheets in the workbook  
            Microsoft.Office.Interop.Excel.Sheets sheets = theWorkbook.Worksheets;
            // get the first and only worksheet from the collection of worksheets  
            Microsoft.Office.Interop.Excel.Worksheet worksheet = (Microsoft.Office.Interop.Excel.Worksheet)sheets.get_Item(1);


            for (int i = 1; i <= 10; i++)
            {
                Microsoft.Office.Interop.Excel.Range range = worksheet.get_Range("A" + i.ToString(), "J" + i.ToString());
                System.Array myvalues = (System.Array)range.Cells.Value;
                string[] strArray = ConvertToStringArray(myvalues);
              
            }
        }


       public static string[] ConvertToStringArray(System.Array values)
        {
            // create a new string array  
            string[] theArray = new string[values.Length];
            // loop through the 2-D System.Array and populate the 1-D String Array  
            for (int i = 1; i <= values.Length; i++)
            {
                if (values.GetValue(1, i) == null)
                    theArray[i - 1] = "";
                else
                    theArray[i - 1] = (string)values.GetValue(1, i).ToString();
            }
            return theArray;
        }
        //private void CC() {
        //    string filePath = @"D:\@ProjectVB2015\ExcelDataReader\ExcelDataReader\สมุดงาน1.xlsx";
        //    FileStream stream = File.Open(filePath, FileMode.Open, FileAccess.Read);
        //    IExcelDataReader excelReader;

        //    //1. Reading Excel file
        //    if (Path.GetExtension(filePath).ToUpper() == ".XLS")
        //    {
        //        //1.1 Reading from a binary Excel file ('97-2003 format; *.xls)
        //        excelReader = ExcelReaderFactory.CreateBinaryReader(stream);
        //    }
        //    else
        //    {
        //        //1.2 Reading from a OpenXml Excel file (2007 format; *.xlsx)
        //        excelReader = ExcelReaderFactory.CreateOpenXmlReader(stream);
        //    }

        //    //2. DataSet - The result of each spreadsheet will be created in the result.Tables
        //    DataSet result = excelReader.AsDataSet();

        //    //3. DataSet - Create column names from first row


        //}
    }
}
